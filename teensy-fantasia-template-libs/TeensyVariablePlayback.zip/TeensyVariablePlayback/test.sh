#!/bin/bash
cd cmake-build-debug/test/
./tests
