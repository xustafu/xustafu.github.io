this example uses [teensy-sample-flashloader](https://github.com/newdigate/teensy-sample-flashloader) to copy samples from the uSD card to the external flash memory
